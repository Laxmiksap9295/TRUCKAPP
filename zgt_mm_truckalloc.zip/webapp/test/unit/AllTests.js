sap.ui.define([
	"com/olam/zgtmmtruckalloc/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
