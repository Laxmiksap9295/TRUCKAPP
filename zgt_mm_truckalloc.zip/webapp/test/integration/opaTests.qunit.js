/* global QUnit */

sap.ui.require(["com/olam/zgtmmtruckalloc/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
